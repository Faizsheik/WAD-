<html>
    <head>
        <title>MainPage</title>
<link rel="stylesheet" href = "stylecommon.css">
    </head>
    <body>
    <div class="full-page">
          <div class="navbar">
            <h1>ACCIDENT ASSISTANCE</h1>
    
        
          <nav>
            <ul id="MenuItems">
            <li><a href="home.html">HOME</a></li>
            <li><a href="about.html">ABOUT US</a></li>;
            <li><a href="siginnew.php">SIGNIN</a></li>
          </ul>
          </nav>
          </div>
            <div class="form-box">
                <div class="button-box">
                <form name="signupform" class="input-group-login" method="post" action="signup.php" onsubmit="return validateForm()">
                <!--<form name= "signupform" onsubmit=" return validateForm()" action="signup.php" method="post">-->

            <label for="username">USERNAME</label>
            <input type="text" class="input-field" name="username" id="uname" placeholder="enter username" required>
            
            <label for="emailid">EMAIL-ID:</label>
            <input type="email" class="input-field" name="emailid" id="eid" placeholder="ex:wwwname@gmail.com" required>
            
            <label for="password">PASSWORD</label>
            <input type="password" class="input-field" name="mypassword" id="pass" placeholder="minimum 7 characters" required width="20px">
            
            <label for="dateofbirth">DATE OF BIRTH</label>
            <input type="date" class="input-field" name="dateofbirth" id="dob" placeholder="DateofBirth" required>
            
            <label for="age">AGE</label>
            <input type="number" class="input-field" name="age" id="age" placeholder="Enter your age" initialized="1" required>
            
            <label for="gender">GENDER</label>
                    <select id="gender" name="genders" class="input-field" width = "50px">
                        <option value = "Male"> Male </option>
                        <option value = "Female"> Female </option>
                    </select>
            
                    <label for="bloodgroup">BLOODGROUP</label>
                <select id="bgroup" name="bloodgroup" class="input-field" width="20px">
                        <option value="A+">A+</option>
                        <option value="B+">B+</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                        <option value="A-">A-</option>
                        <option value="B-">B-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                      </select>

                   <!-- <td><input type="text" name="bloodgroup" id="bgroup" placeholder="Enter your bloodgroup" initialized="1" required></td>-->
                <label for="phonenumber">MOBILE NUMBER</label>
                <input type="tel" class="input-field" name="phonenumber" id="phnum" placeholder="Enter your mobile number" length="10" required>
                <label class="check-box"><input type="checkbox" required="required"> I accept the Privacy Policy</a></label>
                    <!--<input type="submit" value="SUBMIT" class="button-box" name="submit" action="vehicle.php"><BR>
                    <button type = "submit" class="button-box" value="NEXT" action="vehicle.php"></button>-->
                   <br> <input type ="submit" class="button-box" name="submit"></a>

                </div>

        </form>
<script>
            /*function validateForm()
            {

                        var x = document.forms["signupform"]["uname"].value;
                        var z= document.forms["signupform"]["eid"].value;
                        var a= document.forms["signupform"]["phnum"].value;
                        var age=document.forms["signupform"]["age"].value;
                        var p=document.forms["signupform"]["password"].value;
                        var passexp=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
                        var phno=/^\d{10}$/;
                        var alphaexp=/^[a-zA-Z\s]+$/;
                        var mailExp = /^([a-z0-9_]+)@([a-z]+).([a-z]{2,5})$/;
                        if(age>80 && age<18)
                        {
                            alert("Age should be greater than 18 or less than 80");
                        }
                        if(!p.match(passexp))
                        {
                            alert("invalid Input Password and Submit 7 to 15 characters which contain only characters, numeric digits,underscore and first character must be a letter");
                            password.focus();
                            return false;

                        }

                        if(x==" ")
                        {
                            alert("Enter valid username contains alphabets a-z,A-Z,-");
                            uname.focus();
                            return false;

                        }
                        if (!x.match(alphaexp))
                        {
                        alert("Invalid Name");
                        uname.focus();
                        return false;
                        }
                        if(!a.match(phno))
                        {
                            alert("Invalid Phone number");
                            phnum.focus();
                            return false;
                        }
                        if(!z.match(mailExp))
                        {
                            alert("Invalid Mail Id");
                            eid.focus();
                            return false;
                        }    
            }*/
        </script>
    </body>
</html>
<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "accidentdb1";
    $conn = mysqli_connect($servername, $username, $password, $db);
    //include ((header('location:vehicle.php')));
    if(!$conn){
        die("Connection failed: ".mysqli_connect_error());
    }
    if(isset($_POST['submit'])){
        $uname = $_POST['username'];
        $email = $_POST['emailid'];
        $pword = $_POST['mypassword'];
        $dobirth = $_POST['dateofbirth'];
        $age = $_POST['age'];
        $gender= $_POST['genders'];
        $bgroup = $_POST['bloodgroup'];
        $pnumber = $_POST['phonenumber'];
        $insert_sql = "INSERT INTO signup(username, emailid, mypassword, dateofbirth,
         age, genders, bloodgroup,phonenumber) VALUES
         ('$uname', '$email','$pword', '$dobirth','$age','$gender','$bgroup','$pnumber')";
         $result=mysqli_query($conn,$insert_sql);
        if(isset($_POST['submit']))
        {
            echo' <script>
            window.location.href="vehicle.php";
            </script>';
            //header('Location: vehicle.php');
        }        
        if(!mysqli_query($conn, $insert_sql)) {
            echo "Error: " . $insert_sql . "<br>" . mysqli_error($conn);
        }
    }
    mysqli_close($conn);
?>
<!--header ('Location: vehicle.php');
        //header ('Location: alert.html');
        //include 'vehicle.php';
        //windows.location("vehicle.php");
    if(isset($_POST['submit']))
        {
            echo '<script>
            windows.location="vehicle.php";
            </script>';
            //header('Location: vehicle.php');
        }   -->