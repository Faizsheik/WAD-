<html>
    <head>
        <title>MainPage</title>
        <link rel="stylesheet" href="stylecommon.css">
        <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css">-->
        <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/footers/">
        <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">

    </head>
    <body>
        <div class="full-page">
          <div class="navbar">
            <h1>ACCIDENT ASSISTANCE</h1>
    
        
            <nav>
              <ul id="MenuItems">
              <li><a href="home.html">HOME</a></li>
              <li><a href="about.html">ABOUT US</a></li>;
              <li><a href="siginnew.php">SIGNIN</a></li>
              <li><a href="signup.php">SIGNUP</a></li>>
              <li><a href="admin.php">ADMIN</button></a>&emsp;&emsp;
            </ul>
           </div>
          <h1 class="center">WELCOME TO ACCIDENT ASSISTANCE SYSTEM</h1>
          </div>

        
        </div><br><br>
                 
    </body>
      <footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <p class="col-md-4 mb-0 text-muted">&copy; 2022 Company, Inc</p>
    
        <a href="/" class="col-md-4 d-flex align-items-center justify-content-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
          <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"/></svg>
        </a>
    
        <ul class="nav col-md-4 justify-content-end">
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Home</a></li>
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Features</a></li>
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Pricing</a></li>
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">FAQs</a></li>
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">About</a></li>
        </ul>
      </footer>
    
</html>