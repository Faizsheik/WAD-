<html>
    <head>
        <title>ADMIN</title>
        <style>
                .form-box
                {
                    width:480px;
                    height:300px;
                    position:relative;
                    margin:2% auto;
                    background:rgba(237, 239, 227, 0.553);
                    padding:10px;
                    overflow: hidden;
                }
                .button-box
                {
                    width:220px;
                    margin:35px auto;
                    position:relative;
                    box-shadow: 0 0 20px 9px #ff61241f;
                    border-radius: 30px;
                }
                .input-group-login
                {
                    margin-top: 1%;
                    position:absolute;
                    width:280px;
                    transition:.5s;
                }
                .full-page
                {
                    height: 99%;
                    width: 100%;
                    background-image: linear-gradient(rgba(0,0,0,0.4),rgba(0,0,0,0.4)),url(https://c1.wallpaperflare.com/preview/412/860/56/traffic-autos-vehicles-road.jpg);
                    background-position: center;
                    background-size: cover;
                    position: relative;
                }
                .navbar
{
    display: flex;
    align-items: center;
    padding: 20px;
    padding-left: 50px;
    padding-right: 30px;
    padding-top: 50px;
}
nav
{
    flex: 1;
    text-align: right;
}
nav ul 
{
    display: inline-block;
    list-style: none;
}
nav ul li
{
    display: inline-block;
    margin-right: 70px;
}
nav ul li a
{
    text-decoration: none;
    font-size: 20px;
    color: white;
    font-family: sans-serif;
}
nav ul li button
{
    font-size: 20px;
    color: white;
    outline: none;
    border: none;
    background: transparent;
    cursor: pointer;
    font-family: sans-serif;
}
nav ul li button:hover
{
    color: aqua;
}
nav ul li a:hover
{
    color: aqua;
}
.navbar1
{
    align-items:center;
    height: 27px;
}

.btn
{
    background-color:grey;
}
        </style>
    </head>
    <body>
        <div class="full-page">
                    <div class="navbar">
                        <h1 style="color: white">ACCIDENT ASSISTANCE</h1>
                                <nav>
                                    <ul id="MenuItems">
                                    <li><a href="home.html">HOME</a></li>
                                    <li><a href="about.html">ABOUT US</a></li>;
                                    <li><a href="siginnew.php">SIGNIN</a></li>
                                    <li><a href="signup.php">SIGNUP</a></li>>
                                    </ul>
                                </nav>
         </div>
                    <h2 class="center">WELCOME TO ACCIDENT ASSISTANCE SYSTEM</h2>
                    <div class="center">
                            <div class="form-box">
                                <div class="button-box">
                                        <h2>ADMIN LOGIN</h2>
                                        <form name="adminForm" onsubmit="return validateAdminForm()" method="post" action="admin.php" class="input-group-login" >
                                        <input type="email" name="emailid" placeholder="email" required id="mail"/><br><br>
                                
                                        <input type="password" placeholder="password" name="mypassword" required/><br><br>
                                        <centre><a href="admindashold.php"><input type="submit" value="LOGIN" name="submit" id="password1"/></a>
                                        <h3>Don't have an account?</h3>
                                        <a href="adminsignup.php">SIGNUP HERE</a></centre>
                                        </form>
                                        <h2>&nbsp;</h2>
                                </div>
                           </div>
            </div>
        </div>
          
        <br><br>

<script>
    function validateAdminForm()
    {
                var z= document.forms["signinnewform"]["mail"].value;
                var mailExp = /^([a-z0-9_]+)@([a-z]+).([a-z]{2,5})$/;

                var p=document.forms["signinnewform"]["password"].value;
                var passexp=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
                if(z==" ")
                {
                    alert("Enter valid username contains alphabets a-z,A-Z,-");
                    mail.focus();
                    return false;
                }
                
                else if(!z.match(mailExp))
                {
                        alert("Invalid Mail Id");
                        mail.focus();
                        return false;

                }
                if(!p.match(passexp))
                {
                            alert("invalid Input Password and Submit 7 to 15 characters which contain only characters, numeric digits,underscore and first character must be a letter");
                             //password.focus();
                            return false;

                }        
    }
</script>       
</body>
</html>
<? php
?>