<html>
    <head>
        <title>MainPage</title>
        <link rel="stylesheet" href="stylecommon.css">
    </head>
    <body>
    <div class="full-page">
          <div class="navbar">
            <h1>ACCIDENT ASSISTANCE</h1>
    
        
          <nav>
            <ul id="MenuItems">
            <li><a href="home.html">HOME</a></li>
            <li><a href="about.html">ABOUT US</a></li>
            <li><a href="siginnew.php">SIGNIN</a></li>
          </ul>
          </nav>
        </div>
          <h1 class="text-box">Vehicle register here!!!</h1>
            <div class="form-box">
                <div class="button-box">
        <form name="vehicleform" class="input-group-login" action="vehicle.php" method="post" onsubmit=" return validateForm()">
        <!--<label for="id">ID</label>
            <input type="number"class="input-field"  name="idnum" id="idnum" disable>-->
        
        <label for="username">USERNAME</label>
            <input type="text"class="input-field"  name="username" id="uname" required>

            <label for="emailid">EMAIL ID:</label>
            <input type="email" class="input-field" name="emailid" id="eid" placeholder="existing emailid" required>
                
                
            <label for="vehiclenum">VEHICLE NUMBER:</label>
            <input type="text" class="input-field" name="vnumber" id="eid" placeholder="TN 00 AN 1100" required>
                
            <label for="vehicletype">VEHICLE TYPE:</label>
            <select name="vehicletype" class="input-field" id="vehicleid" required>
                        <option value="Two">Bike/Scooty</option>
                        <option value="Three">Auto</option>
                        <option value="four">Car</option>
                        <option value="five">Lorry/Tractor</option>
            </select>
            <label for="vehicle date">VEHICLE REGISTER DATE:</label>
                <input type="date" class="input-field" name="vdate" id="dob" placeholder="Vheicle register date" required>
            
            <label for="useraddress"> ADDRESS: </label>
            <textarea rows="4" cols="40" class="input-field" name="address1" placeholder="User address" form="usrform"></textarea>

            <label for="mail">ALTERNATE EMAIL:</label>
            <input type="email" class="input-field" name="altermail" id="mail" placeholder="Alternate email" required>
            
            <label for="aphonenumber">ALTERNATE MOBILE NUMBER</label>
            <input type="tel" class="input-field" name="altermob" id="phnum" placeholder="Alternate mobile number" length="10" required>
                <!--<table border='0' cellpadding='0' cellspacing='0' width='480px' height="100px" align='center'
                 name="register" required> -->
            <input type="submit" value="REGISTER" name="submit" class="button-box"/>
        
            </form>
</div>
</div>
</div>
            <script>
            function validateForm()
            {

                        var x = document.forms["vehicleform"]["uname"].value;
                        var z= document.forms["vehicleform"]["mail"].value;
                        var a= document.forms["vehicleform"]["phnum"].value;
                        var phno=/^\d{10}$/;
                        var alphaexp=/^[a-zA-Z\s]+$/;
                        var mailExp = /^([a-z0-9_]+)@([a-z]+).([a-z]{2,5})$/;
                        /*if(!p.match(passexp))
                        {
                            alert("invalid password.It must have one number,one upper case,one lowercase,and atleast 8 or more characters");
                        }*/
                        if(x==" ")
                        {
                            alert("Enter valid username contains alphabets a-z,A-Z,-");
                        }
                        if (!x.match(alphaexp))
                        {
                        alert("Invalid Name");
                        return false;
                        }
                        if(!a.match(phno))
                        {
                        alert("Invalid Phone number");
                        return false;
                        }
                        if(!z.match(mailExp))
                        {
                        alert("Invalid Mail Id");
                        return false;
                        }       
            }
        </script>
    </body>
</html>
<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "accidentdb1";

    $conn = mysqli_connect($servername, $username, $password, $db);
    //include ((header('location:vehicle.php')));
    if(!$conn){
        die("Connection failed: ".mysqli_connect_error());
    }
    
    if(isset($_POST['username'])){
        $uname = $_POST['username'];
        $vnum = $_POST['vnumber'];
        $em = $_POST['emailid'];
        $vtype = $_POST['vehicletype'];
        $vehidate = $_POST['vdate'];
        //$uaddress = $_POST['address1'];
        $amail= $_POST['altermail'];
        $amob = $_POST['altermob'];
        
        $insert_sql = "INSERT INTO vehicle(username, vnumber,emailid, vehicletype, vdate,altermail, altermob) VALUES
        ('$uname', '$vnum','$em',$vtype', '$vehidate','$amail','$amob')";
        if(isset($_POST['submit']))
        {
            echo' <script>;
            window.location.href="siginnew.php";
            </script>';
            //header('Location: vehicle.php');
        }        
        if(!mysqli_query($conn, $insert_sql)) {
            echo "Error: " . $insert_sql . "<br>" . mysqli_error($conn);
        }
    }
    mysqli_close($conn);
?>