<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Accident Assistance System</title>
        <!-- Favicon-->
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Roboto+Slab:400,100,300,700" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
            <div class="container">
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars ms-1"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
                        <li class="nav-item"><a class="nav-link" href="#home">Home</a></li>
                        <li class="nav-item"><a class="nav-link" href="#services">Services</a></li>
                        <li class="nav-item"><a class="nav-link" href="#guide">Guide</a></li>
                        <li class="nav-item"><a class="nav-link" href="#about">About </a></li>
                        <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead">
            <div class="container">
                <section class="container my-2 bg-dark w-50 text-light p-2">
                    <form class="row g-3 p-3" action="vehicleform.php" method="post" onsubmit=" return validateForm()">
                        <div class="col-md-6">
                            <label for="validationDefault01" class="form-label">NAME</label>
                            <input type="text" class="form-control" id="validationDefault01" name="username" placeholder="enter name" required>
                          </div>
                          <div class="col-md-6">
                            <label for="validationDefault02" class="form-label">EMAIL ID:</label>
                            <input type="email" class="form-control" name="emailid" id="eid" placeholder="existing emailid" required>
                          </div>
                          
                        <div class="col-md-6">
                          <label for="inputEmail4" class="form-label">VEHICLE NUMBER:</label>
                          <input type="text" class="form-control" name="vnumber" id="eid" placeholder="TN 00 AN 1100" required>
                        </div>
                        <div class="col-md-6">
                          <label for="inputPassword4" class="form-label">VEHICLE TYPE</label>
                          <select name="vehicletype" class="form-select" id="vehicleid" required>
                        <option value="Two">Bike/Scooty</option>
                        <option value="Three">Auto</option>
                        <option value="four">Car</option>
                        <option value="five">Lorry/Tractor</option></select>
</div>
                        <div class="col-md-6">
                          <label for="inputAddress" class="form-label">REGISTER DATE</label>
                          <input type="date" class="form-control" name="vdate" id="dob" placeholder="Vheicle register date" required>
                        </div>
                        <div class="col-md-6">
                          <label for="inputAddress2" class="form-label">ALTERNATE EMAIL:</label>
                          <input type="email" class="form-control" name="altermail" id="mail" placeholder="Alternate email" required>
                        </div>
                        <div class="col-md-4">
                          <label for="inputCity" class="form-label">ALTERNATE MOBILE NUMBER:</label>
                          <input type="tel" class="form-control" name="altermob" id="phnum" placeholder="Alternate mobile number" length="10" required>
                        </div>
                        <div class="col-md-12">
                          <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="gridCheck">
                            <label class="form-check-label" for="gridCheck">
                                I accept the Privacy Policy
                            </label>
                          </div>
                        </div>
                        <div class="col-12">
                        <input type ="submit" class="btn btn-primary" name="submit">
                          <!--<button type="submit" class="">Sign in</button>-->
                        </div>
                      </form>
                   </section>
                 
            </div>
        </header>
        </body>
        </html>
        <?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "accidentdb1";

    $conn = mysqli_connect($servername, $username, $password, $db);
    //include ((header('location:vehicle.php')));
    if(!$conn){
        die("Connection failed: ".mysqli_connect_error());
    }
    
    if(isset($_POST['username'])){
        $uname = $_POST['username'];
        $vnum = $_POST['vnumber'];
        $em = $_POST['emailid'];
        $vtype = $_POST['vehicletype'];
        $vehidate = $_POST['vdate'];
        //$uaddress = $_POST['address1'];
        $amail= $_POST['altermail'];
        $amob = $_POST['altermob'];
        
        $insert_sql = "INSERT INTO vehicle(username, vnumber,vehicletype, vdate,emailid, altermail, altermob)
         VALUES
        ('$uname', '$vnum','$vtype','$vehidate','$em', '$amail','$amob')";
        if(isset($_POST['submit']))
        {
            echo' <script>;
            window.location.href="siginnew.php";
            </script>';
            //header('Location: vehicle.php');
        }        
        if(!mysqli_query($conn, $insert_sql)) {
            echo "Error: " . $insert_sql . "<br>" . mysqli_error($conn);
        }
    }
    mysqli_close($conn);
?>