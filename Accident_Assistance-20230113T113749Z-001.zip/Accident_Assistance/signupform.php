<!doctype html>
<html lang="en">
  <head>
    <style>
        *{
    box-sizing: border-box;
    margin: 0;
    padding: 0;
}
body{
    background: url(bg.jpeg);
}
form{
    box-shadow: 2px 6px 100px #ffffff;
}
    </style>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
    <link rel="stylesheet" href="style.css">
    <title>Form Design</title>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
        <div class="container">
            <a class="navbar-brand" href="#page-top"><img src="assets/img/navbar-logo.svg" alt="..." /></a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                Menu
                <i class="fas fa-bars ms-1"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarResponsive">
                <ul class="navbar-nav text-uppercase ms-auto py-4 py-lg-0">
                    <li class="nav-item"><a class="nav-link" href="index_home.html">Home</a></li>
                    <li class="nav-item"><a class="nav-link" href="siginnew.php">Login</a></li>
                    <li class="nav-item"><a class="nav-link" href="#guide">Guide</a></li>
                    <li class="nav-item"><a class="nav-link" href="#about">About </a></li>
                    <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                </ul>
            </div>
        </div>
    </nav>
   <div class="container-fluid bg-dark text-light py-3">
       <header class="text-center">
           <h1 class="display-6">Welcome to our page</h1>
       </header>
   </div>
   <section class="container my-2 bg-dark w-50 text-light p-2">
    <form class="row g-3 p-3" method="post" action="signupform.php" onsubmit="return validateForm()">
        <div class="col-md-6">
            <label for="validationDefault01" class="form-label">Name</label>
            <input type="text" class="form-control" id="validationDefault01" name="username" placeholder="enter name" required>
          </div>
          <div class="col-md-6">
            <label for="validationDefault02" class="form-label">Password</label>
            <input type="password" class="form-control" id="inputPassword4" name="mypassword" placeholder="minimum 7 characters" required>
          </div>
          
        <div class="col-md-6">
          <label for="inputEmail4" class="form-label">Email id</label>
          <input type="email" class="form-control" id="inputEmail4" name="emailid" placeholder="ex:wwwname@gmail.com" required>
        </div>
        <div class="col-md-6">
          <label for="inputPassword4" class="form-label">DOB</label>
          <input type="date" class="form-control" id="inputDate"  name="dateofbirth" placeholder="DateofBirth" required>
        </div>
        <div class="col-12">
          <label for="inputAddress" class="form-label">Address</label>
          <input type="text" class="form-control" id="inputAddress" name="address" placeholder="1234 Main St">
        </div>
        <div class="col-12">
          <label for="inputAddress2" class="form-label">Age</label>
          <input type="text" class="form-control" id="inputAge"  name="age" placeholder="Enter your age" initialized="1" required>
        </div>
        <div class="col-md-4">
          <label for="inputCity" class="form-label">Gender</label>
          <input type="text" class="form-control" id="inputGender" name="genders" placeholder="Male/Female/Other" required>
        </div>
        <div class="col-md-4">
          <label for="inputState" class="form-label">BloodGroup</label>
          <select id="inputState" class="form-select">
            <option selected>Choose...</option>
            <option value="A+">A+</option>
            <option value="B+">B+</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option>
            <option value="A-">A-</option>
            <option value="B-">B-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
          </select>
        </div>
        <div class="col-md-4">
          <label for="inputZip" class="form-label">Mobile number</label>
          <input type="tel" class="form-control" id="input" name="phonenumber" placeholder="Enter your mobile number" length="10" required>
        </div>
        <div class="col-12">
          <div class="form-check">
            <input class="form-check-input" type="checkbox" id="gridCheck">
            <label class="form-check-label" for="gridCheck">
                I accept the Privacy Policy
            </label>
          </div>
        </div>
        <div class="col-12">
        <input type ="submit" class="btn btn-primary" name="submit">
          <!--<button type="submit" class="">Sign in</button>-->
        </div>
      </form>
   </section>
  </body>
</html>
<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "accidentdb1";
    $conn = mysqli_connect($servername, $username, $password, $db);
    //include ((header('location:vehicle.php')));
    if(!$conn){
        die("Connection failed: ".mysqli_connect_error());
    }
    if(isset($_POST['submit'])){
        $uname = $_POST['username'];
        $pword = $_POST['mypassword'];
        $email = $_POST['emailid'];
        $dobirth = $_POST['dateofbirth'];
        $address = $_POST['address'];
        $age = $_POST['age'];
        $gender= $_POST['genders'];
        $bgroup = $_POST['bloodgroup'];
        $pnumber = $_POST['phonenumber'];
        $insert_sql = "INSERT INTO signup(username, mypassword, emailid, dateofbirth, address, 
         age, genders, bloodgroup,phonenumber) VALUES
         ('$uname', '$pword', '$email', '$dobirth','$address', '$age','$gender','$bgroup','$pnumber')";
         $result=mysqli_query($conn,$insert_sql);
        if(isset($_POST['submit']))
        {
            echo' <script>
            window.location.href="vehicleform.php";
            </script>';
            //header('Location: vehicle.php');
        }        
        if(!mysqli_query($conn, $insert_sql)) {
            echo "Error: " . $insert_sql . "<br>" . mysqli_error($conn);
        }
    }
    mysqli_close($conn);
?>
<!--header ('Location: vehicle.php');
        //header ('Location: alert.html');
        //include 'vehicle.php';
        //windows.location("vehicle.php");
    if(isset($_POST['submit']))
        {
            echo '<script>
            windows.location="vehicle.php";
            </script>';
            //header('Location: vehicle.php');
        }   -->