<html>
    <head>
        <title>Head</title>
    <link rel="stylesheet" href="alertstyle.css">
    <meta name="google-signin-client_id" content="133296264714-l2l4onufs2tkiua3465jtsmdm69943pk.apps.googleusercontent.com">
    <script src="https://apis.google.com/js/platform.js" async defer></script>    
</head>
        <body>
   
<div class="container" onclick="onclick">
    <div class="top"></div>
    <div class="bottom"></div>
    <div class="center">
      <h2>Please Login </h2>
      <form name="signinnewform" action="siginnew.php" onsubmit="return validateMyForm()" method="post">
      <input type="email" name="emailid" placeholder="email" required id="mail"/>

      <input type="password" placeholder="password" name="mypassword" required/>
      <centre><a href="alert.html"><input type="submit" value="LOGIN" name="submit" id="password1"/></a>
      <a href="admin.php" style="color:green">Admin? click here!</a></centre><br>
      <h3>Don't have an account?</h3>
        <a href="signupform.php">SIGNUP HERE</a></centre>
        <centre><div class="g-signin2"></div></centre>
      </form>
      <h2>&nbsp;</h2>
    </div>
  </div>
  <script>
    /*function validateMyForm()
    {
                var z= document.forms["signinnewform"]["mail"].value;
                var mailExp = /^([a-z0-9_]+)@([a-z]+).([a-z]{2,5})$/;
                var p=document.forms["signinnewform"]["password"].value;
                var passexp=/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8,15}$/;
                if(z==" ")
                {
                    alert("Enter valid username contains alphabets a-z,A-Z,-");
                    mail.focus();
                    return false;
                }
                
                else if(!z.match(mailExp))
                {
                        alert("Invalid Mail Id");
                        mail.focus();
                        return false;

                }
                if(!p.match(passexp))
                {
                            alert("invalid Input Password and Submit 7 to 15 characters which contain only characters, numeric digits,underscore and first character must be a letter");
                             //password.focus();
                            return false;

                }        
    }
</script>
</body>
</html>
<?php
    $servername = "localhost";
    $username = "root";
    $password = "";
    $db = "accidentdb1";

    $conn = mysqli_connect($servername, $username, $password, $db);

    if(!$conn){
        die("Connection failed: ".mysqli_connect_error());
    }

    if(isset($_POST['emailid']))
    {
        $em = $_POST['emailid'];
        $pword = $_POST['mypassword'];
        $flag = 0;

        $extract_sql = "SELECT * FROM signup";
        $result = mysqli_query($conn, $extract_sql);

        if (mysqli_num_rows($result) > 0) {
            while($row = mysqli_fetch_assoc($result)) {
                if(($row["emailid"]==$em) && ($row["mypassword"]==$pword)){
                    header ('Location: alert.php');
                    //include 'alert.html';
                    //echo "Successfully Loged In";
                    $flag = 1;
                }
            }
        }

        if($flag ==  0){
            include 'result_false.html';
            //echo "No Such User Available";
        }
    }
    mysqli_close($conn);
?>