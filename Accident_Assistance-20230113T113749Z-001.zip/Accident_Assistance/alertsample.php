<html>
    <head>
        <title></title>
</head>
<body>
    <form action="alertsample.php" method="post">
<label>Subject of email:</label><br>
<input type="text" name="subject" id="subject"/><br>
<label>Body of email:</label><br>
<textarea name="body" id="body" rows="10" cols="35"></textarea><br>
<input type="submit" name=submit value="Submit"/>
</form>
</body>
</html>
<?php

//Block 1
$servername = "localhost";
$username = "root";
$password = "";
$db = "accidentdb1";
$table = "vehicle"; 

//Block 2
$from= 'email_address';

//Block 3
$subject= $_POST['subject'];
$body= $_POST['body'];

//Block 4
$conn = mysqli_connect($servername, $username, $password, $db);
if(!$conn){
    die("Connection failed: ".mysqli_connect_error());
}

//Block 5
$query= "SELECT * FROM $table";
$result= mysqli_query ($conn, $query) 
or die ('Error querying database.');

//Block 6
while ($row = mysqli_fetch_array($result)) {
$first_name= $row['username'];
$last_name= $row['vnumber'];
$email= $row['altermail'];

//Block 7
$msg= "Dear $first_name $last_name,\n$body";
ini_set("SMTP","ssl://smtp.gmail.com");
ini_set("smtp_port","465");
mail($email, $subject, $msg, 'From:' . $from);
echo 'Email sent to: ' . $email. '<br>';
}

//Block 8
mysqli_close($conn);
?>