<html>
    <head>
        <title>MainPage</title>
        <link rel="stylesheet" href="stylecommon.css">
        <!--<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css">-->
        <link rel="canonical" href="https://getbootstrap.com/docs/5.2/examples/footers/">
        <link href="../assets/dist/css/bootstrap.min.css" rel="stylesheet">

    </head>
    <body>
        <div class="full-page">
          <div class="navbar">
            <h1>ACCIDENT ASSISTANCE</h1>
    
        
            <nav>
              <ul id="MenuItems">
              <li><a href="home.html">HOME</a></li>
              <li><a href="about.html">ABOUT US</a></li>;
              <li><a href="admin.php">SIGNIN</a></li>
              <li><a href="adminsignup.php">SIGNUP</a></li>>
              <!--<li><a href="admin.php">ADMIN</button></a>&emsp;&emsp;-->
              <li><a href="admin.php">LOG OUT</a></li>>

            </ul>
           </div>
          <h1 class="center">WELCOME TO ACCIDENT ASSISTANCE SYSTEM</h1>
          </div>

        
        </div><br><br>
                 
<?php
  /*include("signup.php");
 // error_reporting(1);
$insert_sql=("select * from signup");
$data=mysqli_connect($conn,$insert_sql);
$total=mysqli_num_rows($data);
$result=$mysqli_fetch_assoc($data);
echo $result['username'];
echo "$total";
if($total!=0)
{
  echo "Table has records";
}
else
{
  echo "No records found";
}*/
$servername = "localhost";
    $username = "root";
    $password = "";
    $database = "accidentdb1";
    $mysqli = new mysqli($servername, $username, $password, $database);
     $query="select username,emailid from signup";
     echo '<table border="1" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">USERNAME</font> </td> 
          <td> <font face="Arial">MAIL ID</font> </td> 

      </tr>';

if ($result = $mysqli->query($query)) 
{

  while ($row = $result->fetch_assoc())
   {
      
      $field1name = $row["username"];
      $field2name = $row["emailid"];
      //echo '<b>'.$field1name."\t".$field2name.'</b><br />';
      echo 
      '<tr> 
      <td>'.$field1name.'</td> 
      <td>'.$field2name.'</td> 

      
      </tr>';
  }
}

/*freeresultset*/
$result->free();


 /*<footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top">
        <p class="col-md-4 mb-0 text-muted">&copy; 2022 Company, Inc</p>
    
        <a href="/" class="col-md-4 d-flex align-items-center justify-content-center mb-3 mb-md-0 me-md-auto link-dark text-decoration-none">
          <svg class="bi me-2" width="40" height="32"><use xlink:href="#bootstrap"/></svg>
        </a>
    
        <ul class="nav col-md-4 justify-content-end">
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Home</a></li>
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Features</a></li>
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">Pricing</a></li>
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">FAQs</a></li>
          <li class="nav-item"><a href="#" class="nav-link px-2 text-muted">About</a></li>
        </ul>
  </footer>*/
  $query="select username,altermail,vnumber from vehicle";
  echo "\r\n";
  echo "\r\n";
     echo '<table border="1" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">USERNAME</font> </td> 
          <td> <font face="Arial">ALTERNATE MAILID</font> </td> 
          <td> <font face="Arial">VEHICLE NUMBER</font> </td> 

      </tr>';

if ($result = $mysqli->query($query)) 
{

  while ($row = $result->fetch_assoc())
   {
      $field3name = $row["username"];
      $field4name = $row["altermail"];
      $field5name = $row["vnumber"];

      //$field3name = $row["phonenumber"];
      //$field4name = $row["altermail"];
      //$field5name = $row["vnumber"];

      //echo '<b>'.$field1name."\t".$field2name.'</b><br />';
      echo 
      '<tr> 
      <td>'.$field3name.'</td> 
      <td>'.$field4name.'</td> 
      <td>'.$field5name.'</td> 

      
      </tr>';
  }
}

/*freeresultset*/
$result->free();
?>
</body>
</html>